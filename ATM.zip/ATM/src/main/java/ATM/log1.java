package ATM;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * Servlet implementation class log1
 */
public class log1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	HttpSession sesson;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public log1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter pr = response.getWriter();
		String acc = request.getParameter("ano");
		sesson = request.getSession();
		sesson.setAttribute("ano", acc);
		String user = request.getParameter("uno");
		String pass = request.getParameter("p");
//		Jdbc connection check Account no , userId, password match or not
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gdb", "root", "");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from ATMuser where AccountNO='" + acc + "' and UserId='" + user
					+ "' and Password='" + pass + "'");
			if (rs.next()) {
				response.sendRedirect("menu.html");
			}else {
				response.sendRedirect("userpasswrong.html");
			}
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
