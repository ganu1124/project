 package ATM;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class bal
 */
public class bal extends HttpServlet {
	private static final long serialVersionUID = 1L;
	HttpSession sesson;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public bal() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter pr = response.getWriter();
		sesson = request.getSession();
		sesson=request.getSession(false);  
        String acc=(String)sesson.getAttribute("ano");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gdb", "root", "");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from atmuser where AccountNO="+acc+"");
			if (rs.next()) {
				String name = rs.getString(3);
				double bal = rs.getDouble(4);
				pr.println(name);
				pr.println(bal);
				sesson.setAttribute("name", name);
				sesson.setAttribute("bal", bal);
				RequestDispatcher rd = request.getRequestDispatcher("balance.jsp");
				rd.forward(request, response);
			con.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
